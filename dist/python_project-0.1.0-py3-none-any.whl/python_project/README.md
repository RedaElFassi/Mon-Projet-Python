# python_project

A package that uses pybacktest

## Installation

```bash
$ pip install python_project
```

## Usage

- TODO

## Contributing

Interested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.

## License

`python_project` was created by Reda El Fassi. It is licensed under the terms of the MIT license.

## Credits

`python_project` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).
