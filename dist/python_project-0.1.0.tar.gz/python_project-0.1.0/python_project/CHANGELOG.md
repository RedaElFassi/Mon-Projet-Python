# Changelog

<!--next-version-placeholder-->

## v0.1.0 (09/01/2025)

- First release of `python_project`!